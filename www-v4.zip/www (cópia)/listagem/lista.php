<?php
	require("conectaBd.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style/style.css">
	<title>Lista de dados</title>
</head>
<body>
	<?php
		$pesquisa = $_POST['pesquisa'];
		$sql = "select * from cliente where nome LIKE '%$pesquisa%' ";
		$ds=mysqli_query($conn,$sql);
		if(!$ds){
			die("Erro na pesquisa na tabela");
		}
		if(mysqli_num_rows($ds)==0){
			die("Não há dados");
		}else{
			echo("<table>");
				echo("<tr>");
					echo("<th>CPF</th>");
					echo("<th>NOME</th>");
					echo("<th>TELEFONE</th>");
				echo("</tr>");
				while($linhaBd = mysqli_fetch_assoc($ds)){
					$cpf = $linhaBd['cpf'];
					$nome = $linhaBd['nome'];
					$tel = $linhaBd['telefone'];
					echo("<tr>");
						echo("<td>$cpf</td>");
						echo("<td>$nome</td>");
						echo("<td>$tel</td>");
					echo("</tr>");
				}
			echo("</table>");
		}
	?>
</body>
</html>