<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/estilos03.css">
		<link rel="stylesheet" type="text/css" href="css/estiloresp01.css">
		<link rel="shortcut icon" type="image/jpg" href="images/ale.jpg">	
		<title>Lib-Lab</title>
	</head>
	<body>
		<header class="topnav">
			<li>
				<button class="btnLib">
					<b>Lib-Lab</b>
				</button>
			</li>
			<li class="right">
				<a href="cad01.php">
					<button class="btnCadastrar"><b>Cadastro</b></button>
				</a>
			</li>
			<li class="right">
				<a href="login01.php">
					<button class="btnEntrar"><b>Login</b></button>
				</a>
			</li>
		</header>
		<article>
			
			<p class="pIndex">APRENDA LIBRAS COM JOGOS!</p>
			<!--	<a href="cad01.php">
					<button class="btnComecar"><b>Comece Já</b></button>
				</a>-->
			
			<div class="ContArt">
				<p class="pAprenda">
					<b>Para que serve o "Lib-Lab"?</b>
				</p>
				<p class="expli">
						Lorem ipsum dolor sit amet, consectetur
						adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore
						magna aliqua. Ut enim ad minim veniam,<br>
						quis nostrud exercitation ullamco
						 laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in 
						reprehenderit in voluptate velit esse<br>
						cillum dolore eu fugiat nulla 
						pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia <br>
						deserunt mollit anim id est laborum.
				</p>
			</div>
			<div class="imgArt">
				
			</div>
		</article>
		<section class="ExpliFunciona">
			<br>
			<div class="txtImg">
				<p class="Como"><b>Como Funciona?</b></p>
				<p>O LibLab funciona através da gamificação, é preciso completar aulas e exercícios, para que novos níveis e objetivos se debloqueiem</p>
			<br>
				<img class="imgFun02" src="images/funciona02.png">
			</div>				
			<div class="imgTxt">
			<br>
			<br>
				<img class="imgFun01" src="images/funciona01.png">
			<br><br><br>
			<br><br><br>
				<p>Os contéudos são apresentados através de imagens,<br> texto, vídeos e gifts animados.</p>
			</div>
		</section>
		<div>
			<p class="porque">Por que usar o Lib-Lab?</p>
			<div class="colunas">
				<div class="coluna01">
					<img src="##"><br><br>
					<img src="##">
				</div>
				<div class="coluna02">
					Simples de jogar e divertido
					<br><br>
					Design intuitivo e níveis para passar
				</div>
				<div class="coluna01">
					<img src="##"><br><br>
					<img src="##">
				</div>
				<div class="coluna02">
					Ensina a 2° Língua Oficial do Brasil
					<br><br>
					Libras traz  inclusão, combate ao <br>
					preconceito e  destaque profissional
				</div>
			</div>
		</div>
		<footer>
			<p><b>Fale Conosco (mande sugestões e criticas) </b></p>
		</footer>
	</body>
</html>