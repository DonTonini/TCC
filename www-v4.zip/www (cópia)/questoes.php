<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
.mySlides {
	display:none;
		margin:100px;
}
</style>
<body>

<h2>Manual Slideshow</h2>

<div>
	<div class="mySlides">
			<h1>Questão 1</h1>
			<p>Relacione a imagem com a tradução correta:</p>
			<img src=""><br><button>opção 1 </button>
			<br><button>opção 2 </button>
			<br><button>opção 3 </button>
			<br><button>opção 4 </button>
	</div>
	
	<div class="mySlides">
			<h1>Questão 2</h1>
			<p>Relacione a imagem com a tradução correta:</p>
			<img src=""><br><button>opção 1 </button>
			<br><button>opção 2 </button>
			<br><button>opção 3 </button>
			<br><button>opção 4 </button>
	</div>
		
	<div class="mySlides">
			<h1>Questão 3</h1>
			<p>Relacione a imagem com a tradução correta:</p>
			<img src=""><br><button>opção 1 </button>
			<br><button>opção 2 </button>
			<br><button>opção 3 </button>
			<br><button>opção 4 </button>
	</div>
		
	<div class="mySlides">
			<h1>Questão 4</h1>
			<p>Relacione a imagem com a tradução correta:</p>
			<img src=""><br><button>opção 1 </button>
			<br><button>opção 2 </button>
			<br><button>opção 3 </button>
			<br><button>opção 4 </button>
	</div>

	<button onclick="plusDivs(1)">Próxima</button>
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
	showDivs(slideIndex += n);
}

function showDivs(n) {
	var i;
	var x = document.getElementsByClassName("mySlides");
	if (n > x.length) {slideIndex = 1}
	if (n < 1) {slideIndex = x.length}
	for (i = 0; i < x.length; i++) {
		x[i].style.display = "none";  
	}
	x[slideIndex-1].style.display = "block";  
}
</script>

</body>
</html>
