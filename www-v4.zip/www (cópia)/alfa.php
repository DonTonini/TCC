<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/estilos03.css">
	</head>
	<body>
		<p>Alfabeto</p>
		<div class="grup4">
			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra A</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra B</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra C</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra D</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra E</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra F</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra G</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra H</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra I</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra J</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra K</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra L</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra M</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra N</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra O</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra P</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra Q</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra R</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra S</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra T</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra U</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra V</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra W</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra X</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra Y</p>
					</div>
				</div>
			</div>

			<div class="divDasCards">
				<div class="card">
					<div class="cardFrente">
						<img src="A.png" alt="Avatar" style="width:300px;height:300px;">
					</div>
					<div class="cardAtras">
						<p>Letra Z</p>
					</div>
				</div>
			</div>
		</div>

	</body>
</html>
