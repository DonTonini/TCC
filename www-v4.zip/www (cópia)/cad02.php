<?php
	require("crip2gr4.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Cadastro - Tela 2</title>
		<link rel="stylesheet" type="text/css" href="css/estilos03.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	</head>
	<body>				
				<header class="topnav">
			<li>
				<button class="btnLib">
					<b>Lib-Lab</b>
				</button>
			</li>
			<li class="right">
				<a href="cad01.php">
					<button class="btnCadastrar"><b>Cadastro</b></button>
				</a>
			</li>
			<li class="right">
				<a href="login01.php">
					<button class="btnEntrar"><b>Login</b></button>
				</a>
			</li>
		</header>
		<br><br><br><br>
			<?php 
			//os vetores (definidos entre []) foram definidos no campo "name" do cad01
			//campo operador
				if(!isset($_POST['email'])){
					echo"O email não foi preenchido! Retorne para a página de <a href='cad01.php'>cadastro</a><br>					";
				}
				$email=$_POST['email'];
				if (strlen($email)<5) {
					die ("Um email necessita de pelo menos 5 digitos. Retorne para a página de <a href='cad01.php'>cadastro</a><br>");
				}else {
					echo"email: $email <br>";
				}
			//campo username
				if(!isset($_POST['email'])){
					echo"O email não foi preenchido! Retorne para a página de <a href='cad01.php'>cadastro</a><br>";
				}
				$username=$_POST['username'];
				if (strlen($username)<=4) {
					die("O username não foi preenchido corretamente. Retorne para a página de <a href='cad01.php'>cadastro</a><br>");
				}else{
					echo"username: $username <br>";
				}
			//campo password
				if(!isset($_POST['password'])){
					die("Senha não foi transmitida! Retorne para a página de <a href='cad01.php'>cadastro</a><br>");
				}else{
					$senha=$_POST['password'];	
					if (strlen($senha)<5) {
						die("Senha necessita de pelo menos 5 digitos. Retorne para a página de <a href='cad01.php'>cadastro</a><br>");
					}
				}

			/*
			//checagem do sexo 
				$sex=$_POST['sexo'];
				if (!isset($sex)){
					die("Você precisa escolher o campo sexo! Retorne para a página de <a href='cad01'>cadastro</a><br>");
				}else{
					echo"Sexo: $sex <br>";
				}
			//dataNasc
				$data=$_POST['date'];//$data é uma variavel local, criada para realizar a ligação com o nascimento atraves do metodo post.
				echo"Nacimento: $data <br>";*/
			//mostra operador
				echo"<br>Operador email= ".$_SESSION['operador'];
				$operador=$_SESSION['operador'];//vairavel operador chama o email da sessaõ

			//require vem do conectaBd----------------------------------------------------------
				require("conectaBd.php");//ganha a variavel $conn
				echo("<br><br>Conseguiu conectar!<br>");
				//tentar cadastrar
				$sql ="INSERT INTO username ";
				$sql.="(email,username,senha,sexo,dtNasc,operador) ";
				$sql.="VALUES "; //todos os valores sao texto
				$sql.="(?,?,?,?,?,? ) "; //substituicao dos textos por parametros ?
				
				$stmt = mysqli_prepare($conn,$sql);
				if (!$stmt){
					die("Impossivel preparar o cadastro no BD");
				}
				//antes de bindar parametros no BD temos que preparar a senha
				$senha = FazSenha($email,$senha);//troca a digitada sem criptografia, pela criptografada
				$bind = mysqli_stmt_bind_param($stmt,"ssssss",$email,$username,$senha,$sex,$data,$operador);
				if (!$bind){
					die("Impossivel vincular dados ao cadastro");
				}
				$exec = mysqli_stmt_execute($stmt);
				if(!$exec){
					echo("Não consegui inserir os dados no Banco! <br> Retorne para a página de <a href='cad01'>cadastro</a>e tente novamente: <a class='link' href='cad01.php'>Cadastro</a>");
				}else{
					echo("Dados no Banco! Acesse o Menu<br>");
				}
				mysqli_stmt_close($stmt);

			?>				
		</div>
	</body>
</html>