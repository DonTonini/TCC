<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Cadastro Tela-1</title>
		<link rel="stylesheet" type="text/css" href="css/estilos03.css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	</head>
	<body class="formcad" onload="document.form1.email.focus()"><!--Realiza o foco na caixa de texto-->
		<header class="topnav">
			<li>
				<button class="btnLib">
					<b>Lib-Lab</b>
				</button>
			</li>
			<li class="right">
				<a href="cad01.php">
					<button class="btnCadastrar"><b>Cadastro</b></button>
				</a>
			</li>
			<li class="right">
				<a href="login01.php">
					<button class="btnEntrar"><b>Login</b></button>
				</a>
			</li>
		</header>
		<form name="form1" id="form1" method="POST" onsubmit="return validar()" action="cad02.php"> 
			<p><b>Cadastro</b></p>
			<label for="senha">Email:</label>
			<input type="text" name="email" minlength="5" maxlength="50" size="40" placeholder="Email" id="email" autocomplete="off">
			<label for="senha">Nome de Usuário:</label>
			<input type="text" name="username" maxlength="150" size="40" value="" placeholder="Username" id="username" autocomplete="off">
			<label for="senha">Senha:</label>
			<input type="password" name="password" minlength="8" maxlength="50" size="25" placeholder="Password" id="password"><br>
			<input type="submit" name="submit" id="submit" value="Cadastrar">
			<a href="login01.php">Já tem conta? Entrar</a>
		</form>
	</body>
</html>